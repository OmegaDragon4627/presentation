from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),  # ✅ this fixes 404
    path('dashboard/', views.dashboard, name='dashboard'),  # we'll make this next
]
